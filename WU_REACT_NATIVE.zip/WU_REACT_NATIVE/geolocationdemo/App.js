import * as React from 'react';
import { StatusBar } from 'expo-status-bar';
import { Dimensions } from 'react-native';
import { StyleSheet, Text, View } from 'react-native';
import MapView, { Callout,Marker,Circle,} from 'react-native-maps';
import * as Location from "expo-location";

export default function App() {
  const [pin,setPin] = React.useState({
    latitude: 19.075984,
    longitude: 72.877656
  });
  React.useEffect(() => {
    (async () => {
      let {status} = await Location.requestForegroundPermissionAsync();
      if(status != "Granted") {
        setErrorMsg("Permissioon denied");
        return;
      }

      let location=await Location.getCurrentPositionAsync({});
      setLocation(location);
    

      setPin({
        latitude:location.coords.latitude,
        longitude: location.coords.longitude
      });
    })();
  },[]);
  return (
    <View style={styles.container}>
      <MapView style={styles.map} 
      initialRegion={{
        latitude: 19.075984,
        longitude: 72.877656,
        latitudeDelta: 0.0922,
        longitudeDelta: 0.0421
      }}
      showsUserLocation={true}
      onUserLocationChange = {(e) =>{
        console.log("onUserLocationChange",e.nativeEvent.coordinate);
        setPin({
          latitude:e.nativeEvent.coordinate.latitude,
         longitude: e.nativeEvent.coordinate.longitude
           });
      }

      }
      >

        <Marker coordinate={{latitude:19.075984, longitude:72.877656}}
          title="test title" 
          description="test description" 
          pinColor="red"
          draggable={true}
          onDragstart= {(e) => {
            console.log("Drag start", e.nativeEvent.coordinate)
          }}
          onDragEnd = {(e) => {
            console.log("Drag End",e.nativeEvent.coordinate);

            setPin({
            latitude:e.nativeEvent.coordinate.latitude,
           longitude: e.nativeEvent.coordinate.longitude
             });
          }}>
            <Callout>
              <Text>This Is Callout</Text>
            </Callout>
        </Marker>
        <Circle center={pin} 
        radius={200}>

        </Circle>

      </MapView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
  map: {
    width:Dimensions.get("window").width,
    height:Dimensions.get("window").height,
}
});