import { initializeApp } from "firebase/app";
import { getFirestore } from 'firebase/firestore';
import { getAnalytics } from 'firebase/analytics';

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyAY_z42cu1D98c7ETa5l7fQbxSR3K995Jc",
    authDomain: "user-list-ddbac.firebaseapp.com",
    projectId: "user-list-ddbac",
    storageBucket: "user-list-ddbac.appspot.com",
    messagingSenderId: "325444943102",
    appId: "1:325444943102:web:9e9c8c8073f3487b05f9af",
    measurementId: "G-ZB5S8LRLD6"
};

// Initialize Firebase
const app=initializeApp(firebaseConfig);
const analytics=getAnalytics(app);
export default getFirestore()