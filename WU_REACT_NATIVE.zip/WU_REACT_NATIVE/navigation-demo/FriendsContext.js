import React from 'react';

export const FriendsContext = React.createContext();