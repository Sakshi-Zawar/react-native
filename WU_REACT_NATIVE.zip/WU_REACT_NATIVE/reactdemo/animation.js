import React, { Component } from 'react';
 
import { View, Animated, TouchableWithoutFeedback, StyleSheet } from 'react-native';
 
const styles = StyleSheet.create({
 
container: {
 
flex: 1,
 
alignItems: 'center',
justifyContent: 'center'
 
},
 
 box: {
 
width: 150,
 
height: 150,
 
backgroundColor: 'tomato'
 
}
 
});
 
class MyComponent extends Component {
constructor(props) {
 
super(props);
 
this.state = {
animation: new Animated.Value(0)
 
};
 
}
 
startAnimation = () => {
 
Animated.timing(this.state.animation, {
 
toValue: 200,
 
duration: 10
 
}).start();
 
}
 
render() {
 
const animatedStyles = {
transform: [
 
{ translateY: this.state.animation }
 
 ]
 
};
 
return (
 
<View style={styles.container}>
 
<TouchableWithoutFeedback onPress={this.startAnimation}>
 
<Animated.View style={[styles.box, animatedStyles]} />
 
</TouchableWithoutFeedback>
 
</View>
 
);
 
}
}
 
export default MyComponent;