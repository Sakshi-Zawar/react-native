import React, { Component } from 'react';
 
import { View, Text, StyleSheet, FlatList } from 'react-native';
 
import axios from 'axios';
 
const styles = StyleSheet.create({
 
container: {
 
flex: 1,
 
padding: 20
 
},
 
item: {
 
padding: 10,
 
fontSize: 18,
 
height: 44
 
}
 
});
 
class MyComponent extends Component {
 
constructor(props) {
 
super(props);
 
this.state = {
 
data: null
 
};
 
}
 
componentDidMount() {
 
axios.get('https://jsonplaceholder.typicode.com/posts')
 
 .then(response => {
 
this.setState({ data: response.data });
})
 
.catch(error => {
 
console.error(error);
 
});
 
}
 
render() {
 
const { data } = this.state;
 
if (!data) {
 
return (
 
<View style={styles.container}>
 
<Text style={styles.text}>Loading...</Text>
 
</View>
 
);
}
 
return (
 
<FlatList
 
style={styles.container}
 
data={data}
 
renderItem={({ item }) => (
 
<Text style={styles.item}>{item.title}</Text>
 
)}
 
keyExtractor={item => item.id.toString()}
 
/>
 
);
 
}
 
}
 
export default MyComponent;