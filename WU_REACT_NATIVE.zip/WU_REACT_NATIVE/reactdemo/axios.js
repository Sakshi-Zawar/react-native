import React, { Component } from 'react';
 
import { View, Text, StyleSheet } from 'react-native';
 
import axios from 'axios';
 
const styles = StyleSheet.create({
 
container: {
 
flex: 1,
 
justifyContent: 'center',
 
alignItems: 'center'
 
},
 
text: {
 
fontSize: 20,
 
textAlign: 'center'
 
}
 
});
 
class MyComponent extends Component {
 
constructor(props) {
 
super(props);
 
this.state = {
 
data: null
 
};
 
}
componentDidMount() {
 
axios.get( 'https://jsonplaceholder.typicode.com/posts ')
 
.then(response => {
 
this.setState({ data: response.data });
 
})
.catch(error => {
console.error(error);
 
});
 
}
 render() {
 
const { data } = this.state;
 
if (!data) {
 
return (
 
<View style={styles.container}>
 
<Text style={styles.text}>Loading...</Text>
 
</View>
 
);
 
}
 
return (
 
<View style={styles.container}>
 
<Text style={styles.text}>Data: {JSON.stringify(data)}</Text>
 
</View>
 
);
 
}
 
}
 
export default MyComponent;

