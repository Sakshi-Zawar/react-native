const PRODUCTS = [
    {
        id: 100,
        name: 'BOATPro HeadPhones',
        price: 1399,
        image: require('../assets/images/headphones.jpg'),
        description: 'BOATPro HeadPhones over-ear wireless headset that has been ergonomically designed to meet the needs of music lovers. The headphones come equipped with the latest Bluetooth v5.0 for instant wireless connectivity. Its powerful 500mAh battery provides playtime of up to 20 hours for an extended audio bliss. Its 50mm dynamic drivers help supply immersive musical experience to the user with immersive sound. The user can utilize the headset via dual connectivity in the form of Bluetooth and AUX.'
    },
    {
        id:101,
        name: 'Bluetooth Speaker',
        price: 1500,
        image: require('../assets/images/bluetooth-speaker.jpg'),
        description: 'This Bluetooth speaker comes with great sound quality and dolby audio feel. It is designed to meet needs of dance and music lovers. It comes with bluetooth wireless technology to connect and play songs also supports USB,'
    },
    {
        id: 103,
        name: 'Noise Airpodes',
        price: 1399,
        image: require('../assets/images/airpodes.jpg'),
        description: 'Noise Airpodes come with briliiant technology of voice and noise cancellation. It is affordable for everyone. Its playback time is approx 15hours.'

    },
    {
        id: 104,
        name: 'Teddy Bear',
        price: 799,
        image: require('../assets/images/teddy.jpg'),
        description: 'Cute Teddy to gift your loved ones.It is soft and comes with size of 4.5 ft'
    },
    {
        id: 105,
        name: 'Toy Car',
        price: 599,
        image: require('../assets/images/toy-car.jpg'),
        description: 'A model car, or toy car, is a miniature representation of an automobile. Other miniature motor vehicles, such as trucks, buses, or even ATVs, etc. are often included in this general category.'
    }
];

export function getProducts(){
    return PRODUCTS;
}

export function getProduct(id){
    return PRODUCTS.find((product) => (product.id == id));
}