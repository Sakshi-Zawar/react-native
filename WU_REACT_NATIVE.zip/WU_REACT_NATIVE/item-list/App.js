import { StatusBar } from 'expo-status-bar';
import { useState } from 'react';
import { Button, StyleSheet, Text, TextInput, View } from 'react-native';
import { ScrollView } from 'react-native-web';

export default function App() {
  const[enteredGoalText, setenteredGoalText]=useState('');
  const[courseGoals, setCourseGoals] = useState([]);
  const[enteredUpdateText , setUpdateGoalText]=useState('');
  //const[enteredUpdatedGoalText,setUpdateEnteredText] = useState('');

  function goalInputHandler(enteredText){
    //console.log(enteredText)
     setenteredGoalText(enteredText)
  }
  function addGoalHandler() { 
    //console.log(enteredGoalText)
    setCourseGoals(currentCourseGoals => [...courseGoals,enteredGoalText])
  }
  function removeGoalHanlder(selectedGoal){
    //console.log(selectedGoal)
      setCourseGoals(courseGoals.filter((goal,curID) => selectedGoal !== curID));
  }
  function goalUpdateHandler(enteredText){
    setUpdateGoalText(enteredText)
  }

  function updateGoal(selectedGoal){
    //console.log(updateGoalId+" "+enteredUpdateText
    //courseGoals[selectedGoal]=enteredUpdateText;
    //setCourseGoals(courseGoals)
    const updateGoalList = courseGoals.map((goal,index)=>{
      if(selectedGoal==index){
        return enteredUpdateText;
      }
      else{
        return goal;
      }
    });
    setCourseGoals(updateGoalList);
  }

  return (
    <View style={styles.appContainer}>

      <View style={styles.inputContainer}> 
      <TextInput style={styles.textInput} placeholder="Your Course Goal !"  onChangeText={goalInputHandler}/>
      <Button title='Add Goals' onPress={addGoalHandler}/>
      </View>
      <ScrollView>
      <View>
      {courseGoals.map((goal,selectedGoal) =>
      <View style={styles.removeContianer}>
      <Text key={selectedGoal}>{goal}</Text>
        {/* <Text>List of goals?</Text> */}
      <Button title='Delete' onPress={() => removeGoalHanlder(selectedGoal)} />
      <TextInput placeholder='Update Goal' onChangeText={goalUpdateHandler} />
      <Button title='Update' onPress={()=> updateGoal(selectedGoal)}/>
        </View>)}
    </View>
    </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  appContainer:{
    padding:50
  },
  inputContainer:{
    flexDirection:'row',
    justifyContent:'space-between'
  },
  textInput:{
    borderColor: '#cccccc',
    borderWidth: 1,
    width: '80%'
  },
  goalContainer:{
    flex:5
  },
  removeContianer:{
    flexDirection:'row',
    justifyContent: 'space-between'
  },
});
